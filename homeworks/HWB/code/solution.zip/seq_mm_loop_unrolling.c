#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "timing.h"
#define N 1500 /* matrix size */

int main (int argc, char *argv[]) 
{
int	i, j, k;
timing_t tstart, tend;
double	a[N][N],           /* matrix A to be multiplied */
	b[N][N],           /* matrix B to be multiplied */
	c[N][N];           /* result matrix C */



  for (i=0; i<N; i++)
    for (j=0; j<N; j++)
      a[i][j]= i+j;

  for (i=0; i<N; i++)
    for (j=0; j<N; j++)
      b[i][j]= i*j;

  for (i=0; i<N; i++)
    for (j=0; j<N; j++)
      c[i][j]= 0;


  get_time(&tstart);
  for (i=0; i<N; i++) {
      for(j=0; j<N; j++) {
          for (k=0; k<N; k+=4) {
              c[i][j] += a[i][k] * b[k][j];
              c[i][j] += a[i][k+1] * b[k+1][j];
              c[i][j] += a[i][k+2] * b[k+2][j];
              c[i][j] += a[i][k+3] * b[k+3][j];
              //c[i][j] += a[i][k+4] * b[k+4][j];
              //c[i][j] += a[i][k+5] * b[k+5][j];
              //c[i][j] += a[i][k+6] * b[k+6][j];
              //c[i][j] += a[i][k+7] * b[k+7][j];
              //c[i][j] += a[i][k+8] * b[k+8][j];
              //c[i][j] += a[i][k+9] * b[k+9][j];
              //c[i][j] += a[i][k+10] * b[k+10][j];
              //c[i][j] += a[i][k+11] * b[k+11][j];
          }
      }
  }
  get_time(&tend);



  printf("*****************************************************\n");

  double c_F = 0.0;
  for (i=0; i<N; i++) {
      for (j=0; j<N; j++) {
          c_F += c[i][j] * c[i][j];
          //printf("%6.2f   ", c[i][j]);
      }
      //printf("\n");
  }
  printf("||c||_F = %6.2f\n", sqrt(c_F));
  printf ("Elapsed Time: %g s.\n", timespec_diff(tstart,tend));
}

