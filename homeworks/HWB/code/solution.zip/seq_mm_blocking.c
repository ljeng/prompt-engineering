#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "timing.h"
#define N 1500 /* matrix size */

int main (int argc, char *argv[]) 
{
int	i, j, k;
timing_t tstart, tend;
int bsize = 25;
double acc;
double	a[N][N],           /* matrix A to be multiplied */
	b[N][N],           /* matrix B to be multiplied */
	c[N][N];           /* result matrix C */



  for (i=0; i<N; i++)
    for (j=0; j<N; j++)
      a[i][j]= i+j;

  for (i=0; i<N; i++)
    for (j=0; j<N; j++)
      b[i][j]= i*j;

  for (i=0; i<N; i++)
    for (j=0; j<N; j++)
      c[i][j]= 0;

  
  get_time(&tstart);
  for (int ii = 0; ii < N; ii += bsize) {
      for (int jj = 0; jj < N; jj += bsize) {
          for (int kk = 0; kk < N; kk += bsize) {
              for (int i = ii; i < ii + bsize; i++) {
                  for (int j = jj; j < jj + bsize; j++ ) {
                      acc = c[i][j];
                      for (int k = kk; k < kk + bsize; k++) {
                          acc += a[i][k] * b[k][j];
                      }
                      c[i][j] = acc;
                  }
              }
          }
      }
  }
  get_time(&tend);

  printf("*****************************************************\n");

  double c_F = 0.0;
  for (i=0; i<N; i++) {
      for (j=0; j<N; j++) {
          c_F += c[i][j] * c[i][j];
          //printf("%6.2f   ", c[i][j]);
      }
      //printf("\n");
  }
  printf("||c||_F = %6.2f\n", sqrt(c_F));
  printf ("Elapsed Time: %g s.\n", timespec_diff(tstart,tend));
}

