#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "timing.h"
#define N 1500 /* matrix size */

int main (int argc, char *argv[]) 
{
int	i, j, k;
timing_t tstart, tend;
int bsize = 150;
double acc00, acc01, acc10, acc11;
double	a[N][N],           /* matrix A to be multiplied */
	b[N][N],           /* matrix B to be multiplied */
	c[N][N];           /* result matrix C */



  for (i=0; i<N; i++)
    for (j=0; j<N; j++)
      a[i][j]= i+j;

  for (i=0; i<N; i++)
    for (j=0; j<N; j++)
      b[i][j]= i*j;

  for (i=0; i<N; i++)
    for (j=0; j<N; j++)
      c[i][j]= 0;

  
  get_time(&tstart);
  for (int ii = 0; ii < N; ii += bsize) {
      for (int jj = 0; jj < N; jj += bsize) {
          for (int kk = 0; kk < N; kk += bsize) {
              for (int i = ii; i < ii + bsize; i += 2) {
                  for (int j = jj; j < jj + bsize; j += 2 ) {
                      acc00 = c[i  ][j  ];
                      acc01 = c[i  ][j+1];
                      acc10 = c[i+1][j  ];
                      acc11 = c[i+1][j+1];
                      for (int k = kk; k < kk + bsize; k++) {
                          acc00 += a[i][k]   * b[k][j  ];
                          acc01 += a[i][k]   * b[k][j+1];
                          acc10 += a[i+1][k] * b[k][j  ];
                          acc11 += a[i+1][k] * b[k][j+1];
                      }
                      c[i  ][j  ] = acc00;
                      c[i  ][j+1] = acc01;
                      c[i+1][j  ] = acc10;
                      c[i+1][j+1] = acc11;
                  }
              }
          }
      }
  }
  get_time(&tend);

  printf("*****************************************************\n");

  double c_F = 0.0;
  for (i=0; i<N; i++) {
      for (j=0; j<N; j++) {
          c_F += c[i][j] * c[i][j];
          //printf("%6.2f   ", c[i][j]);
      }
      //printf("\n");
  }
  printf("||c||_F = %6.2f\n", sqrt(c_F));
  printf ("Elapsed Time: %g s.\n", timespec_diff(tstart,tend));
}

