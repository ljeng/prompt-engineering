import numpy as np
import multiprocessing as mp
import time
import matplotlib.pyplot as plt
import config

plt.rcParams.update(config.pars)

# Sleep for t seconds
def burnTime(t):
	time.sleep(t)

# Main
if __name__ == '__main__':
    N = 16 # The number of jobs
    P = 4  # The number of processes

    # A thread pool of P processes
    pool = mp.Pool(P)

    # Use a variety of wait times
    ratio = []
    wait_time = [1.0e-06, 1.0e-05, 1.0e-04, 1.0e-03, 1.0e-02, 1.0e-01, 1.0,
10.0, 100.0]

    for t in wait_time:
        print("t = ", t)
        # Compute jobs serially and in parallel
        # Use time.time() to compute the elapsed time for each
        
        # Serial job
        serialStart = time.time()
        for i in range(N):
            burnTime(t)
        serialEnd = time.time()
        serialTime = serialEnd - serialStart
        
        # Parallel job
        wait_times = t * np.ones(N)
        parStart = time.time()
        pool.map(burnTime, wait_times)
        parEnd = time.time()
        parallelTime = parEnd - parStart
        
        # Compute the ratio of these times
        ratio.append(serialTime/parallelTime)

    # Plot the results
    print("Plotting...")
    r = 12
    c = 0.75*r
    fig, ax = plt.subplots(1,1, figsize=(r,c))
    ax.plot(wait_time, ratio, ls='-', marker='o', mfc='w', ms=16, mew=3)
    ax.set_xscale('log')
    ax.set_xlabel('Wait Time (sec)')
    ax.set_ylabel('Serial Time (sec) / Parallel Time (sec)')
    ax.set_title('Speedup versus function time')
    ax.grid(True, ls='--', lw=1.75, alpha=0.65)
    plt.tight_layout()
    plt.savefig('P12.png')
    plt.show()
