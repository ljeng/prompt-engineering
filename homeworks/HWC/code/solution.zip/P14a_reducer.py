#!/usr/bin/python

'''
sacamos la media de las valoraciones de las peliculas
'''

import sys

previous = None
sum = 0
cont = 0

for line in sys.stdin:
	
	key, value = line.split('\t')
	
	''' si key es diferente a previous(anterior linea) '''
	if key != previous:
		''' si previous no es vacio (tiene algo) '''
		if previous is not None:
			print previous + '\t' + str(sum / cont)
		previous = key
		sum = 0
		cont = 0
	sum = sum + float(value)
	cont += 1
print previous + '\t' + str(sum / cont)
