#!/usr/bin/python

import sys

for line in sys.stdin:
	#URL in field 6
	line = line.split(" ")
	print( line[6] + "\t1")
