from pyspark import SparkConf, SparkContext, SQLContext
from pyspark.sql.types import*
from pyspark.sql import*
from pyspark.sql import Row
import string

conf = SparkConf().setMaster('local').setAppName('P24_spark')
sc = SparkContext(conf = conf)
sqlContext = SQLContext(sc)

RDDratings = sc.textFile("ratings.csv")

rating_lines = RDDratings.map(lambda x: x.split(","))

ratings = rating_lines.map(lambda p: Row(movieid=p[1],rating=p[2]))

# DataFrames
schema = sqlContext.createDataFrame(ratings)

# Average rating of each movie
avg_movies = schema.groupby('movieid').agg({'rating':'mean'})
avg_movies_final = avg_movies.orderBy("movieid")
avg_movies_final.write.csv('avg_movies')

# Now define ranges

avg_movies.filter(avg_movies['avg(rating)'] < 1).write.csv('avg_movies_1')
avg_movies.filter((avg_movies['avg(rating)'] < 2) AND (avg_movies['avg(rating)'] >1)).write.csv('avg_movies_2')
avg_movies.filter((avg_movies['avg(rating)'] < 3) AND (avg_movies['avg(rating)'] >2)).write.csv('avg_movies_3')
avg_movies.filter((avg_movies['avg(rating)'] < 4) AND (avg_movies['avg(rating)'] >3)).write.csv('avg_movies_4')
avg_movies.filter((avg_movies['avg(rating)'] < 5) AND (avg_movies['avg(rating)'] >4)).write.csv('avg_movies_5')




