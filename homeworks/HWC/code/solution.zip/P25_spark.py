from pyspark import SparkConf, SparkContext, SQLContext
from pyspark.sql.types import*
from pyspark.sql import*
from pyspark.sql import Row
import string
import sys

# Initial configuration
conf = SparkConf().setMaster('local').setAppName('codigo')
sc = SparkContext(conf = conf)
sqlContext = SQLContext(sc)

# Load file
RDDvar = sc.textFile("Meteorite_Landings.csv")

# Map data
meteorites_lines = RDDvar.flatMap(lambda l: l.split("\n"))
space = meteorites_lines.map(lambda l: Row(type=l.split(",")[2],mass=l.split(",")[4]))

# Create DataFrame type-mass
space_schema = sqlContext.createDataFrame(space)

# Average
avg_space = space_schema.groupby('type').agg({'mass': 'mean'})
meteorites.orderBy("type").write.csv('meteorites')
