from pyspark import SparkConf, SparkContext, SQLContext
from pyspark.sql.types import*
from pyspark.sql import*
from pyspark.sql import Row
import string

conf = SparkConf().setMaster('local').setAppName('codigo')
sc = SparkContext(conf = conf)
sqlContext = SQLContext(sc)

RDDvar = sc.textFile("GOOGLE.csv")

lines=RDDvar.map(lambda x: x.split(","))

row_data = lines.map(lambda p: Row(year=p[0].split("-")[0],value=p[5]))

# DataFrames
schema = sqlContext.createDataFrame(row_data)

# Average per year
avg_schema = schema.groupby('year').agg({'value':'mean'})
avg_schema_final = avg_schema.orderBy('year')
avg_schema_final.write.csv('output')
