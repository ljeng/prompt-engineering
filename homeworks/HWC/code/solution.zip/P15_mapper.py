#!/usr/bin/python

import sys
import csv

for line in sys.stdin:
       line = line.split(",")
       if line[4] == "":
            line[4] = "0"
       if not line[3].startswith('"') and line[6] != "":
           print( line[3] +"\t"+ line[4])

 
