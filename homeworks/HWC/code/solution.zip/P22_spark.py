from pyspark import SparkConf, SparkContext
import string

import sys

conf = SparkConf().setMaster('local').setAppName('P22_spark')
sc = SparkContext(conf = conf)

textFileRDD = sc.textFile("access_log")

urlRDD = textFileRDD.map(lambda line: line.split(" ")[6])

count = urlRDD.map(lambda line: [line, 1])

result = count.reduceByKey(lambda x, y: x + y)

result = result.sortByKey()

result.saveAsTextFile("output.txt");
