#!/usr/bin/python

import sys
import re

for line in sys.stdin:
    line = re.sub( r'\n', '', line )
    print line
