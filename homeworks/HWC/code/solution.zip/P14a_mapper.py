#!/usr/bin/python

import sys
import csv

for line in sys.stdin:
       line = line.split(",")
       print line[1] + '\t' + str(line[2])
