#!/usr/bin/python

import sys
import csv

sentence = ""

sys.stdin.next()
	
for line in sys.stdin:
	line = line.split(",")
	line[0] = line[0].split("-")
	print str(line[0][0]) + ";" + line[4]

