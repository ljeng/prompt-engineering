#!/usr/bin/python

import sys
import csv


def getRange(rating):
	
	if rating < 1 or rating == 1:
		return 1
	if rating < 2 or rating == 2:
		return 2
	if rating < 3 or rating == 3:
		return 3
	if rating < 4 or rating == 4:
		return 4
	return 5

for line in sys.stdin:
       line = line.split('\t')
       print str(getRange(float(line[1]))) + '\t' + str(line[0])

			
