#!/usr/bin/python

import sys
import re

pattern = "5.0"

for line in sys.stdin:
    line = re.sub( r'\n', '', line )
    if pattern in line:
        print (line) 
