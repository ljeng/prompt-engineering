from pyspark import SparkConf, SparkContext
import string

import sys

conf = SparkConf().setMaster('local').setAppName('P21_spark')

sc = SparkContext(conf = conf)

pattern = sys.argv[1]

fileRDD = sc.textFile("input.txt")

lines = fileRDD.filter(lambda line: pattern in line)

lines.saveAsTextFile("output.txt");
