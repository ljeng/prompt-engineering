#!/usr/bin/python

import sys
import re

pattern = sys.argv[1]

for line in sys.stdin:
    line = re.sub( r'\n', '', line )
    if pattern in line:
        print (line) 
